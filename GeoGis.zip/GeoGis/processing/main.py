import time
import os

def main():
    print("Processing service started...")
    while True:
        print("Waiting for jobs...")
        time.sleep(60)

if __name__ == "__main__":
    main()
